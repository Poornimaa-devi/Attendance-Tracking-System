import zipfile, os
zip_name='attendance-deploy-v2.zip'
with zipfile.ZipFile(zip_name,'w',zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk('.'):
        if 'venv' in root:
            continue
        for file in files:
            if file.endswith('.zip') or file.endswith('.tar.gz'):
                continue
            file_path=os.path.join(root, file)
            arc=os.path.relpath(file_path, '.').replace(os.sep, '/')
            zipf.write(file_path, arc)
print('created', zip_name)